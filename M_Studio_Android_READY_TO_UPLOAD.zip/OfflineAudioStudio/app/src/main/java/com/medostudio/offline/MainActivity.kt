package com.medostudio.offline

import android.Manifest
import android.content.pm.PackageManager
import android.media.*
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max

private const val SAMPLE_RATE = 44100
private val Ink = Color(0xFF090D18)
private val Panel = Color(0xFF141B2B)
private val Gold = Color(0xFFE5B94F)
private val Muted = Color(0xFF9AA6BA)
private val Green = Color(0xFF42D6A4)

data class AudioTake(val name: String, val file: File, val durationSec: Int, val bytes: Long)
data class MixTrack(val name: String, val file: File, val durationSec: Int, val gain: Float = 1f, val muted: Boolean = false)

class MainActivity : ComponentActivity() {
    private var recorder: AudioRecord? = null
    private var recordingThread: Thread? = null
    @Volatile private var isRecording = false
    private val pcm = ByteArrayOutputStream()
    private var playback: AudioTrack? = null
    private val takes = mutableStateListOf<AudioTake>()
    private val tracks = mutableStateListOf<MixTrack>()
    private var status by mutableStateOf("جاهز للعمل بدون إنترنت")
    private var recording by mutableStateOf(false)
    private var selectedTab by mutableStateOf("استوديو")

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else status = "لازم تسمح باستخدام الميكروفون للتسجيل"
    }
    private val importAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importWav(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshFiles()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = Green, background = Ink, surface = Panel, onPrimary = Ink, onBackground = Color.White, onSurface = Color.White)) {
                StudioScreen(
                    takes = takes, tracks = tracks, status = status, recording = recording, selectedTab = selectedTab,
                    onTab = { selectedTab = it }, onRecord = { toggleRecord() }, onPlay = { playTake(it) },
                    onDelete = { it.file.delete(); refreshFiles(); status = "تم حذف التسجيل" },
                    onImport = { importAudio.launch(arrayOf("audio/wav", "audio/x-wav", "audio/*")) },
                    onGain = { track, gain -> updateTrack(track, gain = gain) },
                    onMute = { track -> updateTrack(track, muted = !track.muted) },
                    onMix = { renderMix() }
                )
            }
        }
    }

    private fun toggleRecord() {
        if (recording) { stopRecording(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        startRecording()
    }

    private fun startRecording() {
        try {
            val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) { status = "الميكروفون غير متاح"; return }
            synchronized(pcm) { pcm.reset() }
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 16384))
            recorder?.startRecording()
            isRecording = true; recording = true; status = "جاري التسجيل — 44.1 kHz / 16-bit"
            recordingThread = thread(name = "MStudioCapture") {
                val buffer = ByteArray(8192)
                while (isRecording) {
                    val count = recorder?.read(buffer, 0, buffer.size) ?: 0
                    if (count > 0) synchronized(pcm) { pcm.write(buffer, 0, count) }
                }
            }
        } catch (e: Exception) {
            status = "تعذر بدء التسجيل: ${e.localizedMessage ?: "خطأ غير معروف"}"
            recording = false; isRecording = false
            try { recorder?.release() } catch (_: Exception) {}; recorder = null
        }
    }

    private fun stopRecording() {
        isRecording = false
        try { recordingThread?.join(1000); recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}; recorder = null
        recording = false
        val data = synchronized(pcm) { pcm.toByteArray() }
        if (data.isNotEmpty()) {
            val file = File(filesDir, "Take_${stamp()}.wav")
            writeWav(file, data, SAMPLE_RATE, 1)
            refreshFiles(); status = "تم حفظ التسجيل وإضافته للمكساج"
        } else status = "لم يتم التقاط صوت"
    }

    private fun importWav(uri: Uri) {
        try {
            val file = File(filesDir, "Imported_${stamp()}.wav")
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { output -> input.copyTo(output) } }
                ?: throw IllegalStateException("تعذر قراءة الملف")
            readWavMono(file)
            refreshFiles(); status = "تم استيراد الملف وإضافته لمسارات المكساج"
        } catch (e: Exception) {
            status = "تعذر استيراد الملف. استخدم WAV PCM 16-bit بتردد 44.1kHz (${e.message ?: "صيغة غير مدعومة"})"
        }
    }

    private fun refreshFiles() {
        val files = filesDir.listFiles { f -> f.extension.equals("wav", true) }?.sortedByDescending { it.lastModified() } ?: emptyList()
        takes.clear(); tracks.clear()
        files.forEach { file ->
            val duration = ((file.length() - 44).coerceAtLeast(0) / (SAMPLE_RATE * 2)).toInt()
            takes.add(AudioTake(file.nameWithoutExtension, file, duration, file.length()))
            if (!file.name.startsWith("Mix_")) tracks.add(MixTrack(file.nameWithoutExtension, file, duration))
        }
    }

    private fun updateTrack(track: MixTrack, gain: Float? = null, muted: Boolean? = null) {
        val i = tracks.indexOfFirst { it.file == track.file }
        if (i >= 0) tracks[i] = tracks[i].copy(gain = gain ?: tracks[i].gain, muted = muted ?: tracks[i].muted)
    }

    private fun playTake(take: AudioTake) {
        thread(name = "MStudioPlayback") {
            try {
                val samples = readWavMono(take.file)
                val bytes = ByteBuffer.allocate(samples.size * 2).order(ByteOrder.LITTLE_ENDIAN).apply { samples.forEach { putShort(it) } }.array()
                val min = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(SAMPLE_RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(max(min, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
                playback = track; track.play()
                var offset = 0
                while (offset < bytes.size) { val n = track.write(bytes, offset, minOf(8192, bytes.size - offset)); if (n <= 0) break; offset += n }
                track.stop(); track.release(); playback = null
            } catch (_: Exception) { status = "تعذر تشغيل الملف" }
        }
        status = "جاري تشغيل ${take.name}"
    }

    private fun renderMix() {
        val snapshot = tracks.toList().filterNot { it.muted }
        if (snapshot.isEmpty()) { status = "أضف مسارًا صوتيًا أولًا"; return }
        status = "جاري تجهيز المكساج..."
        thread(name = "MStudioMix") {
            try {
                val decoded = snapshot.map { it to readWavMono(it.file) }
                val length = decoded.maxOf { it.second.size }
                val out = ByteArray(length * 2)
                val buffer = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until length) {
                    var sum = 0.0
                    decoded.forEach { (track, samples) -> if (i < samples.size) sum += samples[i].toInt() * track.gain }
                    buffer.putShort(sum.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort())
                }
                val file = File(filesDir, "Mix_${stamp()}.wav")
                writeWav(file, out, SAMPLE_RATE, 1)
                runOnUiThread { refreshFiles(); status = "تم تصدير المكساج كملف WAV داخل المشاريع" }
            } catch (e: Exception) { runOnUiThread { status = "فشل المكساج: ${e.localizedMessage}" } }
        }
    }

    private fun readWavMono(file: File): ShortArray {
        val bytes = file.readBytes()
        require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") { "ملف WAV غير صالح" }
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var offset = 12; var channels = 0; var rate = 0; var bits = 0; var format = 0; var dataOffset = -1; var dataSize = 0
        while (offset + 8 <= bytes.size) {
            val id = String(bytes, offset, 4); val size = b.getInt(offset + 4).coerceAtLeast(0)
            val start = offset + 8
            if (id == "fmt " && start + 16 <= bytes.size) { format = b.getShort(start).toInt(); channels = b.getShort(start + 2).toInt(); rate = b.getInt(start + 4); bits = b.getShort(start + 14).toInt() }
            if (id == "data") { dataOffset = start; dataSize = minOf(size, bytes.size - start); break }
            offset = start + size + (size and 1)
        }
        require(format == 1 && (channels == 1 || channels == 2) && rate == SAMPLE_RATE && bits == 16 && dataOffset >= 0) { "الصيغة المطلوبة PCM 16-bit / 44.1kHz" }
        val frameCount = dataSize / (2 * channels)
        val result = ShortArray(frameCount)
        var p = dataOffset
        for (i in 0 until frameCount) {
            val left = b.getShort(p).toInt(); p += 2
            val value = if (channels == 2) { val right = b.getShort(p).toInt(); p += 2; (left + right) / 2 } else left
            result[i] = value.toShort()
        }
        return result
    }

    private fun writeWav(file: File, data: ByteArray, rate: Int, channels: Int) {
        FileOutputStream(file).use { out ->
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(data.size + 36); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(channels.toShort())
            h.putInt(rate); h.putInt(rate * channels * 2); h.putShort((channels * 2).toShort()); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(data.size); out.write(h.array()); out.write(data)
        }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    override fun onDestroy() {
        if (recording) stopRecording()
        try { playback?.stop(); playback?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
fun StudioScreen(
    takes: List<AudioTake>, tracks: List<MixTrack>, status: String, recording: Boolean, selectedTab: String,
    onTab: (String) -> Unit, onRecord: () -> Unit, onPlay: (AudioTake) -> Unit, onDelete: (AudioTake) -> Unit,
    onImport: () -> Unit, onGain: (MixTrack, Float) -> Unit, onMute: (MixTrack) -> Unit, onMix: () -> Unit
) {
    val tabs = listOf("استوديو" to Icons.Default.GraphicEq, "المكساج" to Icons.Default.Tune, "المشاريع" to Icons.Default.Folder, "المؤثرات" to Icons.Default.AutoFixHigh)
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel) {
            tabs.forEach { (label, icon) ->
                NavigationBarItem(selected = selectedTab == label, onClick = { onTab(label) }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Gold.copy(alpha = .15f), unselectedTextColor = Muted))
            }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("M STUDIO", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("استوديو الصوت", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                }
                Surface(color = Green.copy(alpha = .12f), shape = RoundedCornerShape(50)) { Text("● OFFLINE", Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(18.dp))
            when (selectedTab) {
                "استوديو" -> {
                    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(17.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("جلسة تسجيل", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("44.1 kHz • 16-bit", color = Muted, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(20.dp)); WaveformPreview(recording); Spacer(Modifier.height(20.dp))
                            Surface(color = if (recording) Color(0xFF5A1E2B) else Gold, shape = RoundedCornerShape(50), modifier = Modifier.size(78.dp).clickable { onRecord() }) {
                                Box(contentAlignment = Alignment.Center) { Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = if (recording) Color.White else Ink, modifier = Modifier.size(32.dp)) }
                            }
                            Spacer(Modifier.height(10.dp)); Text(if (recording) "إيقاف وحفظ" else "ابدأ التسجيل", color = if (recording) Color(0xFFFF8795) else Gold, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp)); Text(status, color = Muted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("أحدث التسجيلات", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("${takes.size} ملف", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    if (takes.isEmpty()) EmptyState() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(takes.take(5), key = { it.file.name }) { TakeCard(it, onPlay, onDelete) } }
                }
                "المكساج" -> {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("استيراد WAV") }
                        Button(onClick = onMix, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Icon(Icons.Default.GraphicEq, null); Spacer(Modifier.width(5.dp)); Text("تصدير المكس") }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("مسارات الصوت • ${tracks.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("تحكم في مستوى كل مسار أو اكتمه قبل دمج المسارات في ملف WAV واحد.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    if (tracks.isEmpty()) EmptyState() else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(tracks, key = { it.file.name }) { track ->
                            Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(13.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AudioFile, null, tint = Gold)
                                        Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)) {
                                            Text(track.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            Text("${track.durationSec} ثانية", color = Muted, fontSize = 10.sp)
                                        }
                                        TextButton(onClick = { onMute(track) }) { Text(if (track.muted) "تشغيل" else "كتم", color = if (track.muted) Green else Muted) }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("المستوى", color = Muted, fontSize = 10.sp)
                                        Slider(value = track.gain, onValueChange = { onGain(track, it) }, valueRange = 0f..2f, modifier = Modifier.weight(1f), enabled = !track.muted, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold))
                                        Text("${(track.gain * 100).toInt()}%", color = Gold, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                "المشاريع" -> {
                    Text("المشاريع المحفوظة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (takes.isEmpty()) EmptyState() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(takes, key = { it.file.name }) { TakeCard(it, onPlay, onDelete) } }
                }
                else -> {
                    Text("أدوات معالجة الصوت", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("المتاح حاليًا: تسجيل WAV، استيراد WAV، تشغيل الملفات، التحكم في مستوى المسارات، كتم المسارات، ودمجها دون إنترنت.", color = Muted, lineHeight = 21.sp)
                    Spacer(Modifier.height(12.dp))
                    listOf("Equalizer متعدد النطاقات" to "قيد التطوير", "Reverb و Echo" to "قيد التطوير", "Noise Reduction" to "قيد التطوير", "Compressor و Limiter" to "قيد التطوير", "Pitch و Time Stretch" to "قيد التطوير").forEach { (name, state) ->
                        Surface(color = Panel, shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.GraphicEq, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text(name, color = Color.White, modifier = Modifier.weight(1f)); Text(state, color = Muted, fontSize = 10.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun WaveformPreview(active: Boolean) {
    Canvas(Modifier.fillMaxWidth().height(84.dp)) {
        val mid = size.height / 2; val count = 72
        for (i in 0 until count) {
            val h = (7 + ((i * 37) % 30)).toFloat() * if (active) 1.3f else 1f
            val x = i * size.width / count
            drawLine(if (active) Green else Gold.copy(alpha = .8f), Offset(x, mid - h), Offset(x, mid + h), strokeWidth = 3f)
        }
        drawLine(Color.White.copy(alpha = .18f), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 1f)
    }
}

@Composable fun EmptyState() {
    Box(Modifier.fillMaxWidth().padding(26.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.LibraryMusic, null, tint = Gold, modifier = Modifier.size(36.dp)); Spacer(Modifier.height(8.dp)); Text("لا توجد ملفات صوتية بعد", color = Muted) }
    }
}

@Composable fun TakeCard(t: AudioTake, play: (AudioTake) -> Unit, del: (AudioTake) -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Gold.copy(alpha = .14f), shape = RoundedCornerShape(11.dp), modifier = Modifier.size(40.dp).clickable { play(t) }) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Gold) } }
            Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) {
                Text(t.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("${t.durationSec} ثانية • WAV • ${t.bytes / 1024} KB", color = Muted, fontSize = 10.sp)
            }
            IconButton(onClick = { play(t) }) { Icon(Icons.Default.PlayCircle, null, tint = Gold) }
            IconButton(onClick = { del(t) }) { Icon(Icons.Default.DeleteOutline, null, tint = Muted) }
        }
    }
}
